/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */
package ds.edu.readaholic.ui.bookshelf;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Cache;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import ds.edu.readaholic.Utility;
import ds.edu.readaholic.databinding.FragmentBookshelfBinding;
import ds.edu.readaholic.ui.explore.BookAdapter;

/**
 * This class is responsible for displaying the bookshelf page.
 * Bookshelf is a collection of user favorite books.
 * It gets data from MongoDB server through the webservice.
 * To get dynamic data, it occupies BookshelfViewModel class.
 */
public class BookshelfFragment extends Fragment {

    // we use RecyclerView to display the list of books
    private RecyclerView rvBooks;
    private List<BookAdapter.Book> bookExplore = new ArrayList<>();

    // binding is used to bind the layout with the fragment similar with findViewById method
    private FragmentBookshelfBinding binding;

    private boolean webServerStatus = true;
    private boolean liveDataStatus = false;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        BookshelfViewModel bookshelfViewModel =
                new ViewModelProvider(this).get(BookshelfViewModel.class);

        binding = FragmentBookshelfBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // this page manages its own recycler view, rv_books on fragment_bookshelf.xml
        rvBooks = binding.rvBooks;
        rvBooks.setHasFixedSize(true);

        // progressOverlay is used to show the progress bar while fetching data from the server
        View progressOverlay = binding.progressBar;

        // check internet connection to handle network failure, unable to reach server
        if(Utility.isOnline(getContext())) {
            progressOverlay.setVisibility(View.VISIBLE);

            // change development status in Utility class to switch server easily
            String url = new Utility().getActiveURL()+"/bookshelf";

            /**
             * Cite: https://google.github.io/volley/
             * I use Volley library to fetch data from the server since AsyncTask is deprecated
             * It has cache mechanism to store data locally and retry policy to handle network failure
             * We don't need to create Background thread since Volley has its own thread
             * That's why it makes our code cleaner and easier to read
              */
            RequestQueue requestQueue;
            Cache cache = new DiskBasedCache(getContext().getCacheDir(), 1024 * 1024); // 1MB cap
            Network network = new BasicNetwork(new HurlStack());
            requestQueue = new RequestQueue(cache, network);
            requestQueue.start();

            // lambda expression to handle request-response data to webservice
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // when we got response, parse it the next step
                        showRecyclerList(response);

                        // store the response data to the ViewModel, to keep data when moving to another intent
                        bookshelfViewModel.setData(response);

                        progressOverlay.setVisibility(View.INVISIBLE);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // We will notify to user through Toast if the server is unavailable
                        Toast.makeText(getContext(), "Third-party API or Webservice Unavailable", Toast.LENGTH_SHORT).show();
                        progressOverlay.setVisibility(View.INVISIBLE);
                    }
                });

            // set retry policy to avoid application sending request too often
            RetryPolicy policy = new DefaultRetryPolicy(10000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);

            // add the request to the queue
            requestQueue.add(stringRequest);

        } else {
            // We will notify to user through Toast if there is no internet connection
            Toast.makeText(getContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
        }

        // observe the data from the ViewModel to keep the data when moving to another intent
        bookshelfViewModel.getData().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String data) {

                // for efficiency, we only reload the data if the server is available and the data is not empty
                if(webServerStatus && !liveDataStatus){
                    showRecyclerList(data);
                }
            }
        });

        return root;
    }

    /**
     * This method is used to show the list of books in the recycler view
     * @param data is the response data from the server
     */
    private void showRecyclerList(String data){

        // Use BookAdapter class to construct JSON data format
        Gson gsonResponse = new Gson();
        BookAdapter bookAdapter = gsonResponse.fromJson(data, BookAdapter.class);

        // check the status of the response data
        if(!bookAdapter.getStatus().equals("OK")){
            // We will notify to user through Toast if there is error in the response data
            Toast.makeText(getContext(), bookAdapter.getStatus(), Toast.LENGTH_SHORT).show();
            webServerStatus = false;
        }else{

            // check if the response data is empty
            if(bookAdapter.getBooks().size() == 0){
                Toast.makeText(getContext(), "No Books Found", Toast.LENGTH_SHORT).show();
            }else{

                // if all conditions are met, we can display the list of books
                liveDataStatus = true;

                bookExplore.clear();

                bookExplore.addAll(bookAdapter.getBooks());

                // show the list of books in the recycler view
                rvBooks.setLayoutManager(new LinearLayoutManager(getActivity()));
                bookAdapter = new BookAdapter(bookExplore);
                rvBooks.setAdapter(bookAdapter);
            }
        }
    }

    /**
     * This method is used to destroy the binding when the fragment is destroyed
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}