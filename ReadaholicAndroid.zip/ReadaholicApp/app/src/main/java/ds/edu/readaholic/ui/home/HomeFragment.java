/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */
package ds.edu.readaholic.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Cache;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import ds.edu.readaholic.Utility;
import ds.edu.readaholic.databinding.FragmentHomeBinding;
import ds.edu.readaholic.ui.explore.BookAdapter;

/**
 * This class is responsible for displaying the home page.
 * Home page is a collection of user search history.
 * It gets data from MongoDB server through the webservice.
 * To get dynamic data, it occupies HomeViewModel class.
 */
public class HomeFragment extends Fragment {
    private RecyclerView rvHistory;
    private FragmentHomeBinding binding;
    private List<BookAdapter.Book> bookHome = new ArrayList<>();
    public static volatile boolean mongoServerStatus = true;

    /**
     * This method is responsible for creating the view of the home page.
     * @param inflater is used to inflate the layout
     * @param container is the parent view that the fragment's UI should be attached to
     * @param savedInstanceState is a reference to a Bundle object that is passed into the onCreate method of Activity
     * @return root
     */
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // we use recycleview rv_history to display the list of search history
        rvHistory = binding.rvHistory;
        rvHistory.setHasFixedSize(true);

        // Error Handling: Mobile App Network Failure
        if(Utility.isOnline(getContext())) {

            if(bookHome.size() == 0 && mongoServerStatus) {

                // change development status in Utility class to switch server easily
                String url = new Utility().getActiveURL()+"/history";

                // we use Volley to fetch data from the server
                RequestQueue requestQueue;
                Cache cache = new DiskBasedCache(getContext().getCacheDir(), 1024 * 1024); // 1MB cap
                Network network = new BasicNetwork(new HurlStack());
                requestQueue = new RequestQueue(cache, network);
                requestQueue.start();

                /**
                 * This method is responsible for fetching data from the server.
                 * @param url is the URL of the server
                 * @param response is the response from the server
                 */
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                // continue the process to the next step
                                showRecyclerList(response);
                                // set data to the view model
                                HomeViewModel.setData(response);
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // show error message when the server is unavailable
                                Toast.makeText(getContext(), "Third-party API or Webservice Unavailable", Toast.LENGTH_SHORT).show();
                            }
                        });

                RetryPolicy policy = new DefaultRetryPolicy(10000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                stringRequest.setRetryPolicy(policy);

                // add the request to the queue
                requestQueue.add(stringRequest);
            }

        } else {
            // show error message when there is no internet connection
            Toast.makeText(getContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
        }

        /**
         * This method is responsible for observing the data from the view model.
         * @param data is the data from the view model
         */
        homeViewModel.getData().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String data) {
                // for efficiency, we only reload the data if the server is available
                if(mongoServerStatus){
                    showRecyclerList(data);
                }
            }
        });

        return root;
    }

    /**
     * This method is responsible for showing the list of books in the recycler view.
     * @param data is the response data from the server
     */
    private void showRecyclerList(String data){

        Gson gsonResponse = new Gson();

        // Use SearchHistory class to construct JSON data format
        SearchHistory searchHistory = gsonResponse.fromJson(data, SearchHistory.class);

        // check the status of the response data
        if(!searchHistory.getStatus().equals("OK")){
            // show error message when the server is unavailable
            Toast.makeText(getContext(), searchHistory.getStatus(), Toast.LENGTH_SHORT).show();
            mongoServerStatus = false;
        }else{

            // we only take the data from the server if the data is empty when the app is first opened
            if(bookHome.size() == 0) {
                bookHome.addAll(searchHistory.getBooks());
            }

            // set the layout manager and adapter to the recycler view
            rvHistory.setLayoutManager(new GridLayoutManager(getContext(), 3));
            searchHistory = new SearchHistory(bookHome);
            rvHistory.setAdapter(searchHistory);
        }
    }

    /**
     * This method is responsible for destroying the view of the home page.
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}