/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */
package ds.edu.readaholic;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * This helper class is responsible for providing utility functions.
 * It provides the active URL based on the developer mode.
 * It also provides the function to check the internet connection.
 */
public class Utility {
    // URLs for the local servers
    final String DEV_SERVER = "http://10.0.2.2:8080/ReadaholicWS-1.0-SNAPSHOT";
    // URLs for the production servers
    final String PROD_SERVER = "https://ubiquitous-space-waddle-j9jqvqxxgwxhpg77-8080.app.github.dev";

    // after change the server above, change this status to be true to use the local server
    boolean isDeveloperMode = true;

    public String getActiveURL() {
        String activeServer = this.isDeveloperMode ? this.DEV_SERVER : this.PROD_SERVER;
        return activeServer;
    }

    // Cite: https://stackoverflow.com/questions/47052268/internet-connection-issue
    public static boolean isOnline(Context context)
    {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo == null)
            return false;
        if (!netInfo.isConnected())
            return false;
        if (!netInfo.isAvailable())
            return false;
        return true;
    }
}
