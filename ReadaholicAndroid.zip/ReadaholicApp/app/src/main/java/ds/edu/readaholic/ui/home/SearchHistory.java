package ds.edu.readaholic.ui.home;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import ds.edu.readaholic.R;
import ds.edu.readaholic.ui.explore.BookAdapter;
import ds.edu.readaholic.ui.explore.BookDetail;

public class SearchHistory extends RecyclerView.Adapter<SearchHistory.ListViewHolder> {

    private String status;

    private List<BookAdapter.Book> books;

    public String getStatus() {
        return status;
    }

    public SearchHistory(List<BookAdapter.Book> books) {
        this.books = books;
    }

    public List<BookAdapter.Book> getBooks() {
        return books;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items_search_list, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {
        BookAdapter.Book book = books.get(position);

        byte[] decodedString = Base64.decode(book.getThumbnail(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        holder.tvImageHome.setImageBitmap(decodedByte);

        holder.itemView.setOnClickListener(v -> {
            Intent moveToDetail = new Intent(holder.itemView.getContext(), BookDetail.class);
            moveToDetail.putExtra("id", books.get(holder.getAdapterPosition()));
            startActivity(holder.itemView.getContext(), moveToDetail, null);
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        public ImageView tvImageHome;

        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            tvImageHome = itemView.findViewById(R.id.tv_imageHome);
        }
    }
}
