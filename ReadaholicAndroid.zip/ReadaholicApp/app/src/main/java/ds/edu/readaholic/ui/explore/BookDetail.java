/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */
package ds.edu.readaholic.ui.explore;

import static ds.edu.readaholic.R.id.tv_title;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

import ds.edu.readaholic.R;
import ds.edu.readaholic.Utility;

/**
 * This class is responsible for displaying the detail of a book.
 * It gets parcelable data when user clicks a book from the list.
 */
public class BookDetail extends AppCompatActivity {

    /**
     * This method is called when the activity is first created.
     * It gets the data from the parcelable object and displays it on the screen.
     * It also provides the share and favorite button functionality.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // set the layout of the activity as activity_detail_books.xml
        setContentView(R.layout.activity_detail_books);

        ImageView cover = findViewById(R.id.tv_image);
        TextView title = findViewById(tv_title);
        TextView author = findViewById(R.id.tv_author);
        TextView rating = findViewById(R.id.tv_rating);
        TextView desc = findViewById(R.id.tv_desc);
        TextView category = findViewById(R.id.tv_category);
        TextView publisher = findViewById(R.id.tv_publisher);

        /**
         * it has two buttons, share and favorite.
         * share button is used to share the book information to other apps.
         * favorite button is used to add or remove the book from the favorite list.
         */
        Button btnShare = findViewById(R.id.btn_share);
        Button btnFave = findViewById(R.id.btn_fave);

        BookAdapter.Book book;
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            book = getIntent().getParcelableExtra("id", BookAdapter.Book.class);
        } else {
            book = getIntent().getParcelableExtra("id");
        }

        // set the text of the favorite button based on the status of the book
        if (book.getStatusFavorite() == 1) {
            btnFave.setText("Dislike");
        } else {
            btnFave.setText("Like");
        }

        // set the click listener for the share button using implicit intent strategy
        btnShare.setOnClickListener(v -> {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);

            shareIntent.setType("text/plain");
            // Set the content to be shared
            String shareContent = "Check out this book "+book.getTitle()+" by "+book.getAuthors()+". It's a "+book.getCategory()+" book published by "+book.getPublisher()+" on "+book.getYear()+". It has a rating of "+book.getRating();
            // open share dialog
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareContent);
            shareIntent.putExtra(Intent.EXTRA_TITLE, "Share Book");
            // Start the share action
            startActivity(Intent.createChooser(shareIntent, "Share via"));
        });

        // cite: https://www.computerworld.com/article/1389938/how-to-send-a-post-request-with-google-volley-on-android.html
        btnFave.setOnClickListener(v -> {

            // change development status in Utility class to switch server easily
            String postUrl = new Utility().getActiveURL()+"/favbook";

            RequestQueue queue = Volley.newRequestQueue(this);

            // we will use POST method to update the favorite status of the book
            StringRequest sr = new StringRequest(Request.Method.POST,postUrl, new Response.Listener<String>() {
                /**
                 * This method is called when the response is received from the server.
                 * It displays a toast message based on the response.
                 */
                @Override
                public void onResponse(String response) {
                    Gson gsonResponse = new Gson();
                    // Response will be formatted as JSON utilizing BookAdapter structure
                    BookAdapter bookAdapter = gsonResponse.fromJson(response, BookAdapter.class);

                    // check the status of the response data
                    if(!bookAdapter.getStatus().equals("OK")){
                        Toast.makeText(v.getContext(), "Failed to Add Book to Favorite", Toast.LENGTH_SHORT).show();
                    }else{
                        // set the status of the book and display the toast message for like or dislike
                        String info = book.getStatusFavorite() == 1 ? "Remove Book Successfully" : "Add Book Successfully";
                        Toast.makeText(v.getContext(), info, Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                /**
                 * This method is called when the server is unavailable.
                 * It displays a toast message to notify the user.
                 */
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(v.getContext(), "Third-party API or Webservice Unavailable", Toast.LENGTH_SHORT).show();
                }
            }){
                /**
                 * This method is used to pass the parameters to the server.
                 * It sends the ISBN and the status of the favorite book.
                 */
                @Override
                protected Map<String,String> getParams(){
                    Map<String,String> params = new HashMap<>();
                    params.put("isbn", book.getIsbn());
                    params.put("statusFavorite", String.valueOf(book.getStatusFavorite()));
                    return params;
                }

                /**
                 * This method is used to set the header of the request.
                 * It sets the content type to application/x-www-form-urlencoded.
                 */
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();
                    params.put("Content-Type","application/x-www-form-urlencoded");
                    return params;
                }
            };

            // add the request to the queue
            queue.add(sr);
        });

        // decode the base64 string to bitmap and set the image of the book
        byte[] decodedString = Base64.decode(book.getThumbnail(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        cover.setImageBitmap(decodedByte);

        // set the text of the book detail
        title.setText(book.getTitle());
        author.setText(book.getAuthors());
        publisher.setText(book.getPublisher());
        category.setText(book.getCategory());
        String ratingText = "Rating: "+book.getRating() + ". Year: "+book.getYear() + ". Page: "+book.getPageCount();
        rating.setText(ratingText);
        desc.setText(book.getDesc());
    }
}
