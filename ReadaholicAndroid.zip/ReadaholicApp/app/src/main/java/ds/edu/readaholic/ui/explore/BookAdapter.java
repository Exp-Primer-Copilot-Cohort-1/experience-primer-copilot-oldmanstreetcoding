/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */
package ds.edu.readaholic.ui.explore;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import ds.edu.readaholic.R;

/**
 * This class works as a bridge to show the data in recycler view.
 * It serves as a skeleton to display the data in JSON format.
 * We also use this class to handle the click event on the data.
 * It also implements Parcelable to pass the data between intent activities.
 */
public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ListViewHolder> {
    private String status;
    private List<Book> books;

    public BookAdapter(List<Book> books) {
        this.books = books;
    }

    public String getStatus() {
        return status;
    }

    public List<Book> getBooks() {
        return books;
    }

    /**
     * This method is used to create the view holder for the recycler view.
     * It inflates the layout for the recycler view.
     * @param parent   the parent view group
     * @param viewType the view type
     * @return the view holder
     */
    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items_book_list, parent, false);
        return new ListViewHolder(view);
    }

    /**
     * This method is used to bind the data to the view holder.
     * Click event also handle here.
     * @param holder   the view holder
     * @param position the position of the data
     */
    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {

        // get which book has been clicked
        Book book = books.get(position);

        // for efficiency, we decode the image response from base64 to bitmap
        byte[] decodedString = Base64.decode(book.getThumbnail(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

        // set the image, title, author, and rating to the view holder
        String rating = book.getRating();
        holder.tvImage.setImageBitmap(decodedByte);
        holder.tvTitle.setText(book.getTitle());
        holder.tvAuthor.setText(book.getAuthors());
        holder.tvRating.setText(rating);

        /**
         * This method is used to handle the click event on the data.
         * When the data is clicked, it will move to the detail activity bringing the clicked book id.
         */
        holder.itemView.setOnClickListener(v -> {
            Intent moveToDetail = new Intent(holder.itemView.getContext(), BookDetail.class);
            moveToDetail.putExtra("id", books.get(holder.getAdapterPosition()));
            startActivity(holder.itemView.getContext(), moveToDetail, null);
        });
    }

    /**
     * This method is used to get the total number of data as a part of the recycler view.
     * @return the total number of data
     */
    @Override
    public int getItemCount() {
        return books.size();
    }

    /**
     * This method is used to pass the data between intent activities.
     */
    public class ListViewHolder extends RecyclerView.ViewHolder {

        // declare the view holder
        public ImageView tvImage;
        public TextView tvTitle;
        public TextView tvAuthor;
        public TextView tvRating;

        /**
         * This method is used to assign the view holder to the layout.
         * the layour is the items_book_list.xml
         * @param itemView the view holder
         */
        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            tvImage = itemView.findViewById(R.id.tv_image);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvAuthor = itemView.findViewById(R.id.tv_author);
            tvRating = itemView.findViewById(R.id.tv_rating);
        }
    }

    /**
     * This class works as a java bean to store each book data and help structure the JSON data.
     * We keep this class as inner class to make it easier to share across the class.
     */
    public static class Book implements Parcelable {
        private String isbn, title, authors, publisher, year, category, desc, rating, thumbnail, id;
        private int pageCount, statusFavorite;

        // constructor
        public Book(String isbn, String title, String authors, String publisher, String year, String category, String desc, int pageCount, String rating, String thumbnail, String id, int statusFavorite) {
            this.isbn = isbn;
            this.title = title;
            this.authors = authors;
            this.publisher = publisher;
            this.year = year;
            this.category = category;
            this.desc = desc;
            this.pageCount = pageCount;
            this.rating = rating;
            this.thumbnail = thumbnail;
            this.id = id;
            this.statusFavorite = statusFavorite;
        }

        /**
         * This method is implemented parcelable method to pass the data between intent activities.
         */
        protected Book(Parcel in) {
            isbn = in.readString();
            title = in.readString();
            authors = in.readString();
            publisher = in.readString();
            year = in.readString();
            category = in.readString();
            desc = in.readString();
            rating = in.readString();
            thumbnail = in.readString();
            id = in.readString();
            pageCount = in.readInt();
            statusFavorite = in.readInt();
        }

        /**
         * This method is used to create the parcelable object.
         */
        public static final Creator<BookAdapter.Book> CREATOR = new Creator<BookAdapter.Book>() {
            @Override
            public BookAdapter.Book createFromParcel(Parcel in) {
                return new BookAdapter.Book(in);
            }

            @Override
            public BookAdapter.Book[] newArray(int size) {
                return new BookAdapter.Book[size];
            }
        };

        public String getIsbn() {
            return isbn;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthors() {
            return authors;
        }

        public String getPublisher() {
            return publisher;
        }

        public String getYear() {
            return year;
        }

        public String getCategory() {
            return category;
        }

        public String getDesc() {
            return desc;
        }

        public String getRating() {
            return rating;
        }

        public String getThumbnail() {
            return thumbnail;
        }

        public String getId() {
            return id;
        }

        public int getPageCount() {
            return pageCount;
        }

        public int getStatusFavorite() {
            return statusFavorite;
        }

        /**
         * This method implement parcel method.
         */
        @Override
        public int describeContents() {
            return 0;
        }

        /**
         * This method implement parcel method to write the data to the parcel.
         */
        @Override
        public void writeToParcel(@NonNull Parcel dest, int flags) {
            dest.writeString(isbn);
            dest.writeString(title);
            dest.writeString(authors);
            dest.writeString(publisher);
            dest.writeString(year);
            dest.writeString(category);
            dest.writeString(desc);
            dest.writeString(rating);
            dest.writeString(thumbnail);
            dest.writeString(id);
            dest.writeInt(pageCount);
            dest.writeInt(statusFavorite);
        }
    }
}
