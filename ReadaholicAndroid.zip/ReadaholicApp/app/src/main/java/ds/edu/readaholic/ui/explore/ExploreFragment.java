/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */
package ds.edu.readaholic.ui.explore;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Cache;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import ds.edu.readaholic.Utility;
import ds.edu.readaholic.databinding.FragmentExploreBinding;
import ds.edu.readaholic.ui.home.HomeFragment;

/**
 * This class is responsible for displaying the explore page.
 * Explore page is a collection of books based on the search term.
 * It gets data from Google Books API through the webservice.
 * To get dynamic data, it occupies ExploreViewModel class.
 */
public class ExploreFragment extends Fragment{
    private RecyclerView rvBooks;
    private List<BookAdapter.Book> bookExplore = new ArrayList<>();
    private FragmentExploreBinding binding;
    private boolean webServerStatus = true;
    private boolean liveDataStatus = false;

    HomeFragment homeFragment = new HomeFragment();

    /**
     * This method is used to show the validation status.
     * @param validationInfo is the TextView to show the validation status.
     * @param message is the message to be shown.
     */
    private void showValidationStatus(TextView validationInfo, String message){
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
        validationInfo.setText(message);
        validationInfo.setVisibility(View.VISIBLE);
    }

    /**
     * This method is used to show the recycler list.
     */
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        ExploreViewModel exploreViewModel =
                new ViewModelProvider(this).get(ExploreViewModel.class);

        binding = FragmentExploreBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Button submitButton = binding.submit;

        // we use rv_books recycler view on fragment_explore.xml
        rvBooks = binding.rvBooks;
        rvBooks.setHasFixedSize(true);

        View progressOverlay = binding.progressBar;

        TextView validationInfo = binding.validationInfo;

        submitButton.setOnClickListener(new View.OnClickListener(){

            /**
             * This method is used to handle the submit button click event.
             * @param viewParam is the view to be clicked.
             */
            public void onClick(View viewParam) {

                // check internet connection to handle network failure, unable to reach server
                if(Utility.isOnline(getContext())) {

                    // show the progress bar while fetching data from the server
                    progressOverlay.setVisibility(View.VISIBLE);

                    // take the search term from the user input
                    String searchTerm = binding.searchTerm.getText().toString();

                    boolean isError = false;
                    String message = "";

                    // Error Handling: Input Validation
                    if(searchTerm.isEmpty() || searchTerm == null){
                        message = "Enter a Search Term";
                        isError = true;
                    }

                    // We only allow search term with length between 3 and 20
                    if (searchTerm.length() < 3 || searchTerm.length() > 20) {
                        message = "Invalid Keyword length";
                        isError = true;
                    }

                    // We only allow search term with alphanumeric characters
                    if (!Pattern.compile("^[a-zA-Z0-9 ]+$").matcher(searchTerm).matches()) {
                        message = "Keyword should be not empty and alphanumeric";
                        isError = true;
                    }

                    // if there is an error, show the validation status
                    if(isError){
                        showValidationStatus(validationInfo, message);
                        progressOverlay.setVisibility(View.INVISIBLE);
                        return;
                    }

                    // change development status in Utility class to switch server easily
                    String url = new Utility().getActiveURL()+"/books?keyword="+searchTerm;

                    /**
                     * Cite: https://google.github.io/volley/
                     * I use Volley library to fetch data from the server since AsyncTask is deprecated
                     * It has cache mechanism to store data locally and retry policy to handle network failure
                     * We don't need to create Background thread since Volley has its own thread
                     * That's why it makes our code cleaner and easier to read
                     */
                    RequestQueue requestQueue;
                    Cache cache = new DiskBasedCache(getContext().getCacheDir(), 1024 * 1024); // 1MB cap
                    Network network = new BasicNetwork(new HurlStack());
                    requestQueue = new RequestQueue(cache, network);
                    requestQueue.start();

                    // lambda expression to handle request-response data to webservice
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    // when we got response, parse it the next step
                                    showRecyclerList(response);
                                    // store the response data to the ViewModel, to keep data when moving to another intent
                                    exploreViewModel.setData(response);

                                    progressOverlay.setVisibility(View.INVISIBLE);
                                }
                            },
                            new Response.ErrorListener() {
                                /**
                                 * This method is used to handle the error response.
                                 * @param error is the error to be handled.
                                 */
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(getContext(), "Third-party API or Webservice Unavailable", Toast.LENGTH_SHORT).show();
                                    progressOverlay.setVisibility(View.INVISIBLE);
                                }
                            });

                    RetryPolicy policy = new DefaultRetryPolicy(10000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                    stringRequest.setRetryPolicy(policy);

                    // add the request to the queue
                    requestQueue.add(stringRequest);

                } else {
                    // We will notify to user through Toast if there is no internet connection
                    Toast.makeText(getContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }

        });

        /**
         * This method is used to observe the data from the ViewModel to keep the data when moving to another intent.
         */
        exploreViewModel.getData().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String data) {
                if(webServerStatus && !liveDataStatus){
                    showRecyclerList(data);
                }
            }
        });

        return root;
    }

    /**
     * This method is used to show the recycler list.
     * @param data is the response data from the server.
     */
    private void showRecyclerList(String data){
        Gson gsonResponse = new Gson();
        BookAdapter bookAdapter = gsonResponse.fromJson(data, BookAdapter.class);

        // check the status of the response data
        if(!bookAdapter.getStatus().equals("OK")){
            // We will notify to user through Toast if there is error in the response data
            Toast.makeText(getContext(), bookAdapter.getStatus(), Toast.LENGTH_SHORT).show();
            webServerStatus = false;
        }else{
            // if the response data is empty, show the toast message
            if(bookAdapter.getBooks().size() == 0){
                Toast.makeText(getContext(), "No Books Found", Toast.LENGTH_SHORT).show();
            }else{

                // if all conditions are met, we can display the list of books
                liveDataStatus = true;

                TextView validationInfo = binding.validationInfo;
                validationInfo.setVisibility(View.INVISIBLE);
                validationInfo.setText("");

                // clear the previous data, to avoid duplication data in the recycler view
                bookExplore.clear();

                bookExplore.addAll(bookAdapter.getBooks());
                rvBooks.setLayoutManager(new LinearLayoutManager(getActivity()));
                bookAdapter = new BookAdapter(bookExplore);
                rvBooks.setAdapter(bookAdapter);

                // to share update mongoserver status in homefragment
                homeFragment.mongoServerStatus = true;
            }
        }
    }

    /**
     * This method is used to destroy the binding when the fragment is destroyed.
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}