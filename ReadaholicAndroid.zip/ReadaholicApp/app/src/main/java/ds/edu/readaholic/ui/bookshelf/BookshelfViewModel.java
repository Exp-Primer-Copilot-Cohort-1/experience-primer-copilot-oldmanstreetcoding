/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */
package ds.edu.readaholic.ui.bookshelf;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

/**
 * This class works as a container to keep reliable data in bookshelf page
 */
public class BookshelfViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    // constructor
    public BookshelfViewModel() {
        mText = new MutableLiveData<>();
    }

    /**
     * This method is used to fill this container with data
     * @param data the data to be filled
     */
    public void setData(String data) {
        mText.setValue(data);
    }

    /**
     * This method is used to get the data
     * @return the data
     */
    public LiveData<String> getData() {
        return mText;
    }
}