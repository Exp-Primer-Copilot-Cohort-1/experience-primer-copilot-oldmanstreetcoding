/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */
package ds.edu.readaholic.ui.explore;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

/**
 * This class works as data container for ExploreFragment to keep live data.
 */
public class ExploreViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    // Constructor
    public ExploreViewModel() {
        mText = new MutableLiveData<>();
    }

    public void setData(String data) {
        mText.setValue(data);
    }

    public LiveData<String> getData() {
        return mText;
    }
}