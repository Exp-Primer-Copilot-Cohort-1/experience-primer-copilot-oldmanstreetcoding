// @author: Ahmad Furqan (AndrewID: afurqan)
$(document).ready(function() {

    $(document).on("click","#nav-log-tab",function(){
        let url = window.location.href.split("/");
        let homeUrl = url[0]+"//"+url[2]+"/"+url[3]+"/";

        window.location.assign(homeUrl+"logs");

    });

    $(document).on("click","#nav-analytics-tab",function(){
        let url = window.location.href.split("/");
        let homeUrl = url[0]+"//"+url[2]+"/"+url[3]+"/";

        window.location.assign(homeUrl+"analytics");

    });

    $(document).on("click","#nav-home-tab",function(){
        let url = window.location.href.split("/");
        let homeUrl = url[0]+"//"+url[2]+"/"+url[3]+"/";

        window.location.assign(homeUrl);

    });

});