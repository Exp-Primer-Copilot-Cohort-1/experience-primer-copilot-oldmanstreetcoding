/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */

package ds.readaholicws;

import com.google.gson.JsonArray;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * ReadaholicServlet class is a servlet class that handles the HTTP GET and POST requests from the client.
 * We only need one servlet class to handle all the requests from the client utilizing the URL pattern.
 */
@WebServlet(name = "ReadaholicServlet",
        urlPatterns = {"/books","/history", "/favbook", "/bookshelf", "/logs", "/analytics", ""})
public class ReadaholicServlet extends HttpServlet {
    ReadaholicModel readaholicModel;
    MongoDBConnector mongoDBConnector;

    @Override
    public void init() {
        readaholicModel = new ReadaholicModel();
    }

    /**
     * doGet method is responsible for handling the HTTP GET requests from the client.
     * It is responsible for handling the requests
     * 1. /books --> search for books
     * 2. /history --> get the history of the books that the user has searched
     * 3. /bookshelf --> get the list of favorite books
     * 4. /logs --> get the logs of the user activities
     * 5. /analytics --> get the analytics of the user activities
     * 6. / --> default page
     * @param request HttpServletRequest object
     * @param response HttpServletResponse object
     * @throws IOException
     * @throws ServletException
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        long timeWSGetUserRequest = System.currentTimeMillis();

        String url = request.getServletPath();

        mongoDBConnector = new MongoDBConnector();

        // for the log and analytics purpose, we record user identity and request information
        String userAgent = request.getHeader("User-Agent");
        String userIP = request.getRemoteAddr();
        int userPort = request.getRemotePort();
        String routing = request.getServletPath().replace("/", "");
        String reqMethod = request.getMethod();
        String reqURI = request.getRequestURI();
        String protocol = request.getProtocol();
        String scheme = request.getScheme();

        PrintWriter out = response.getWriter();

        // if the request is for searching books
        if (url.equals("/books")) {

            String keyword = request.getParameter("keyword");

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            // besides returning the search result, we also record the user activity
            out.print(readaholicModel.searchBook(keyword, timeWSGetUserRequest, userAgent, userIP, userPort, routing, reqMethod, reqURI, protocol, scheme));

            out.flush();

        }else if(url.equals("/history")){

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            out.print(mongoDBConnector.getHistory(timeWSGetUserRequest, userAgent, userIP, userPort, routing, reqMethod, reqURI, protocol, scheme, "history"));

            out.flush();

        }else if(url.equals("/bookshelf")){

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            out.print(mongoDBConnector.getHistory(timeWSGetUserRequest, userAgent, userIP, userPort, routing, reqMethod, reqURI, protocol, scheme, "bookshelf"));

            out.flush();

        }else if(url.equals("/logs")){

            JsonArray dataLogs = mongoDBConnector.getLogs();

            // set the dataLogs attribute to be used in the dashboard
            request.setAttribute("dataLogs", dataLogs);

            String nextView = "logs.jsp";

            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);

        }else if(url.equals("/analytics")) {

            // beside logs, we also provide 6 analytics data to be displayed in the dashboard
            request.setAttribute("dataCategoryRank", mongoDBConnector.getCategoryRank());
            request.setAttribute("dataKeywordRank", mongoDBConnector.getKeywordRank());
            request.setAttribute("dataSoftwareRank", mongoDBConnector.getDataSummary("logActivity", "softwareAgent"));
            request.setAttribute("dataStatusSummary", mongoDBConnector.getDataSummary("logActivity", "transactionStatus"));
            request.setAttribute("dataRoutingSummary", mongoDBConnector.getDataSummary("logActivity", "routing"));
            request.setAttribute("dataTransactionTrend", mongoDBConnector.getTransactionTrend());

            String nextView = "analytics.jsp";

            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);

        }else{

            String nextView = "index.jsp";

            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }
    }

    /**
     * doPost method is responsible for handling the HTTP POST requests from the client.
     * It handles /favbook request to update the favorite status of the book sent by android client.
     * @param request HttpServletRequest object
     * @param response HttpServletResponse object
     * @throws IOException
     * @throws ServletException
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        long timeWSGetUserRequest = System.currentTimeMillis();

        String url = request.getServletPath();

        String userAgent = request.getHeader("User-Agent");
        String userIP = request.getRemoteAddr();
        int userPort = request.getRemotePort();
        String routing = request.getServletPath().replace("/", "");
        String reqMethod = request.getMethod();
        String reqURI = request.getRequestURI();
        String protocol = request.getProtocol();
        String scheme = request.getScheme();

        PrintWriter out = response.getWriter();

        if (url.equals("/favbook")) {

            String isbn = request.getParameter("isbn");
            String statusFavorite = request.getParameter("statusFavorite");

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            mongoDBConnector = new MongoDBConnector();

            // invoke the updateBook method to update the favorite status of the book
            out.print(mongoDBConnector.updateBook(isbn, Integer.parseInt(statusFavorite), timeWSGetUserRequest, userAgent, userIP, userPort, routing, reqMethod, reqURI, protocol, scheme));

            out.flush();

        }

    }

    public void destroy() {
    }
}
