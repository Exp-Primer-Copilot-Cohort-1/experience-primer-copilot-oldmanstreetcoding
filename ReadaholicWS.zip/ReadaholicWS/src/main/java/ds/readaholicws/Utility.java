/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */

package ds.readaholicws;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import javax.net.ssl.*;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Date;

/**
 * This is a helper class to make the code more readable and maintainable.
 */
public class Utility {

    /** Cite: stackoverflow.com/questions/1086123/is-there-a-method-for-string-conversion-to-title-case
     * This method is to convert the input string to title case.
     * @param input the input string
     * @return the title case string
     */
    public String toTitleCase(String input) {
        if (input == null || input.isEmpty()) {
            return input; // Return input string if it's null or empty
        }

        // Split the input string into words using whitespace as delimiter
        String[] words = input.split("\\s+");

        StringBuilder titleCase = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) { // Skip empty words
                // Capitalize the first letter of the word and append to titleCase
                titleCase.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1).toLowerCase())
                        .append(" "); // Add whitespace after each word
            }
        }

        // Remove trailing whitespace and return the title case string
        return titleCase.toString().trim();
    }

    /**
     * This method is to create the trust manager.
     * @param certType the type of the certificate
     * @throws KeyManagementException
     * @throws NoSuchAlgorithmException
     */
    private void createTrustManager(String certType) throws KeyManagementException, NoSuchAlgorithmException{
        /**
         * Annoying SSLHandShakeException. After trying several methods, finally this
         * seemed to work.
         * Taken from: http://www.nakov.com/blog/2009/07/16/disable-certificate-validation-in-java-ssl-connections/
         */
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        // Install the all-trusting trust manager
        SSLContext sc = SSLContext.getInstance(certType);
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }

    /**
     * This method is to check the trust manager.
     */
    public void checkTrustManager() {

        try {
            createTrustManager("TLSV1.3");
        } catch (KeyManagementException ex) {
            ex.printStackTrace();
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * This method is to check the JSON element format sent by the Google Books API whether it is valid or not.
     */
    public boolean checkJsEl(JsonArray jsonArr, String pointer, int i){
        return jsonArr.get(i).getAsJsonObject().get("volumeInfo").getAsJsonObject().get(pointer) == null ? true : false;
    }

    /**
     * This method is to get the JSON element from the Google Books API.
     * @param jsonArr the JSON array
     * @param pointer the pointer
     * @param i the index
     * @return the JSON element
     */
    public String getJsElement(JsonArray jsonArr, String pointer, int i){
        JsonElement jsEl = jsonArr.get(i).getAsJsonObject().get("volumeInfo").getAsJsonObject().get(pointer);
        if(jsEl != null){
            return jsEl.getAsString();
        }
        return "-";
    }

    /**
     * This method is to convert the date from long to string.
     * @param time the time
     * @return the date
     */
    public static String convertDate(long time){
        if(time == 0){
            return "-";
        }else{
            return new Date(time).toString();
        }
    }

    /**Cite: stackoverflow.com/questions/24417699/encode-image-from-url-in-base64-in-java
     * This method is to convert the image URL to Base64 string.
     * @param imageURL the image URL
     * @return the Base64 string
     * @throws Exception
     */
    public String imageURLToBase64(String imageURL) throws Exception {
        // Create URL object
        URL url = new URL(imageURL);

        // Open connection to the URL
        try (InputStream inputStream = url.openStream();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            // Read image data from the URL
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            // Encode image data to Base64 string
            byte[] imageBytes = outputStream.toByteArray();
            String base64String = Base64.getEncoder().encodeToString(imageBytes);

            return base64String;
        }
    }
}
