/**
 * @author: Ahmad Furqan (AndrewID: afurqan)
 */

/**
 * This class serves as a model class to handle business logic of the web service.
 * It defines functions to search book, insert log, insert book, update book, get logs, get keyword rank, get category rank, get transaction trend, and get data summary.
 * The file also contains a class to store book details.
 * The file also contains a class to interact with MongoDB.
 */

package ds.readaholicws;

import com.google.gson.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;
import java.util.regex.Pattern;

import com.mongodb.client.*;
import com.mongodb.client.model.*;
import org.bson.Document;
import org.bson.conversions.Bson;

import static com.mongodb.client.model.Accumulators.first;
import static com.mongodb.client.model.Aggregates.*;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Projections.*;

/**
 * This class serve as a java bean class to store book details.
 * It defines book attributes and constructor to initialize the book object.
 * I put this class in ReadaholicModel.java file to avoid creating a separate file for it.
 */
class Book {
    private String isbn, title, authors, publisher, year, category, desc, rating, thumbnail, id;
    private int pageCount, statusFavorite;
    public Book(String isbn, String title, String authors, String publisher, String year, String category, String desc, int pageCount, String rating, String thumbnail, String id, int statusFavorite) {
        this.isbn = isbn;
        this.title = title;
        this.authors = authors;
        this.publisher = publisher;
        this.year = year;
        this.category = category;
        this.desc = desc;
        this.pageCount = pageCount;
        this.rating = rating;
        this.thumbnail = thumbnail;
        this.id = id;
        this.statusFavorite = statusFavorite;
    }
}

/**
 * This class serves various function to allow web service to interact with MongoDB.
 * It defines functions to insert logs, insert books, update books, get logs, get keyword rank, get category rank, get transaction trend, and get data summary.
 */
class MongoDBConnector {

    final String URI = "mongodb://afurqan:project4dslab@ac-apj3hcs-shard-00-02.a1tj2al.mongodb.net:27017,ac-apj3hcs-shard-00-01.a1tj2al.mongodb.net:27017,ac-apj3hcs-shard-00-00.a1tj2al.mongodb.net:27017/myFirstDatabase?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
    final String DB_NAME = "Project4_MongoDS";

    /* foundBooks collection will store book list history searched by user to provide bookshelf feature
     * for our android application.
     */
    final String FOUND_BOOKS = "foundBooks";

    final String LOG_ACT = "logActivity";

    /**
     * This function inserts log activity into MongoDB.
     * The logged transactions included book search process, bookshelf update process, initial app launch.
     * @param userAgent User-Agent of the client
     * @param userIP IP address of the client
     * @param userPort Port of the client
     * @param routing Routing of the client
     * @param timeWSGetUserRequest Time when web service get user request
     * @param timeWSSendReqToOthers Time when web service send request to 3rd party
     * @param timeWSGetRepFromOthers Time when web service get response from 3rd party
     * @param timeWSSendRepToUser Time when web service send response to user
     * @param transactionStatus Status of the transaction
     * @param keyWord Keyword used in book searching feature in android application
     * @param jsonString JSON Data of the transaction
     * @param requestMethod Request method of the transaction. e.g. GET, POST
     * @param requestURI Request URI of the transaction. e.g. /books, /bookshelf, /logs
     * @param protocol Protocol of the transaction
     * @param scheme Scheme of the transaction
     * @param countData Count of data in the transaction
     * @param requestQuery Query of the transaction. e.g. collection.find(), API request.
     */
    public void insertLog(String userAgent, String userIP, int userPort, String routing, long timeWSGetUserRequest, long timeWSSendReqToOthers, long timeWSGetRepFromOthers, long timeWSSendRepToUser, String transactionStatus, String keyWord, String jsonString, String requestMethod, String requestURI, String protocol, String scheme, int countData, String requestQuery) {

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            // Check if the database exists
            if (!mongoClient.listDatabaseNames().into(new ArrayList<>()).contains(DB_NAME)) {
                // if it doesn't exist, we will create it
                database.createCollection(LOG_ACT);
            }

            MongoCollection<Document> collection = database.getCollection(LOG_ACT);

            String softwareAgent = "";

            /* to capture OS type/Software used by the client in accessing the web service.
             * in development, we use Postman and Android Emulator to test the web service.
             */
            if(userAgent.contains("PostmanRuntime")) {
                softwareAgent = userAgent.split("/")[0];
            } else if(userAgent.contains("Android")) {
                softwareAgent = userAgent.split(";")[2];
            }

            // information to be stored in the log
            Document logBook = new Document("timeWSGetUserRequest", timeWSGetUserRequest)
                    .append("timeWSSendReqToOthers", timeWSSendReqToOthers)
                    .append("timeWSGetRepFromOthers", timeWSGetRepFromOthers)
                    .append("timeWSSendRepToUser", timeWSSendRepToUser)
                    .append("userAgent", userAgent)
                    .append("softwareAgent", softwareAgent)
                    .append("userIP", userIP)
                    .append("userPort", userPort)
                    .append("routing", routing)
                    .append("keyword", keyWord)
                    .append("WSProcessingTime", timeWSSendRepToUser-timeWSGetUserRequest)
                    .append("otherPartyProcessingTime", timeWSGetRepFromOthers-timeWSSendReqToOthers)
                    .append("transactionStatus", transactionStatus)
                    .append("requestMethod", requestMethod)
                    .append("requestURI", requestURI)
                    .append("protocol", protocol)
                    .append("scheme", scheme)
                    .append("countData", countData)
                    .append("requestQuery", requestQuery)
                    .append("jsonString", jsonString);

            collection.insertOne(logBook);

        }
    }

    /**
     * This function to save book searching history into MongoDB.
     * The book details are fetched from Google Books API.
     * @param isbn ISBN of the book
     * @param title Title of the book
     * @param authors Authors of the book
     * @param publisher Publisher of the book
     * @param year Year of the book
     * @param category Category of the book
     * @param desc Description of the book
     * @param rating Rating of the book
     * @param thumbnail Thumbnail of the book
     * @param id ID of the book
     * @param pageCount Page count of the book
     * @param statusFavorite Status of the book in the bookshelf. 0 for not favorite, 1 for favorite
     * @param userIP IP address of the client
     */
    public void insertBook(String isbn, String title, String authors, String publisher, String year, String category, String desc, String rating, String thumbnail, String id, int pageCount, int statusFavorite, String userIP) {

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            // Check if the database exists
            if (!mongoClient.listDatabaseNames().into(new ArrayList<>()).contains(DB_NAME)) {
                // Database doesn't exist, so create it
                database.createCollection(FOUND_BOOKS);
            }

            MongoCollection<Document> collection = database.getCollection(FOUND_BOOKS);

            // initial statusFavorite is 0 and will be updated to 1 if user add the book to bookshelf
            Document book = new Document("isbn", isbn)
                    .append("title", title)
                    .append("authors", authors)
                    .append("publisher", publisher)
                    .append("year", year)
                    .append("category", category)
                    .append("desc", desc)
                    .append("rating", rating)
                    .append("thumbnail", thumbnail)
                    .append("id", id)
                    .append("statusFavorite", statusFavorite)
                    .append("userIP", userIP)
                    .append("pageCount", pageCount);

            collection.insertOne(book);

        }
    }

    /**
     * This function will be executed when users click like/unlike button in the book details page.
     * @param isbn ISBN of the book
     * @param statusFavorite Status of the book in the bookshelf. 0 for not favorite, 1 for favorite
     * @param timeWSGetUserRequest Time when web service get user request
     * @param userAgent User-Agent of the client
     * @param userIP IP address of the client
     * @param userPort Port of the client
     * @param routing Routing of the client
     * @param requestMethod Request method of the transaction. e.g. GET, POST
     * @param requestURI Request URI of the transaction. e.g. /books, /bookshelf, /logs
     * @param protocol Protocol of the transaction
     * @param scheme Scheme of the transaction
     * @return JSON data of the updated book
     */
    public String updateBook(String isbn, int statusFavorite, long timeWSGetUserRequest, String userAgent, String userIP, int userPort, String routing, String requestMethod, String requestURI, String protocol, String scheme) {

        Gson gson = new Gson();

        String transactionStatus = "-";
        String requestQuery = "-";

        // these set of maps will be used to format Json response
        Map<String, ArrayList<Document>> dataBooks = new HashMap<>();
        Map<String, String> statusMap = new HashMap<>();
        Map<String, Object> responseMap = new HashMap<>();

        long startRegMongo = System.currentTimeMillis();
        long endReqMongo = 0;

        int countData = 0;

        // if user click like button, statusFavorite will be updated to 1, otherwise it will be updated to 0
        int updateStatusFavorite = statusFavorite == 1 ? 0 : 1;

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            MongoCollection<Document> collection = database.getCollection(FOUND_BOOKS);

            Document book = new Document("isbn", isbn);

            // update statusFavorite and userIP of the book based on the ISBN
            Document update = new Document("$set", new Document("statusFavorite", updateStatusFavorite).append("userIP", userIP));
            requestQuery = "collection.updateOne(book, new Document('$set', new Document('statusFavorite', "+updateStatusFavorite+").append('userIP',"+ userIP +")))";

            collection.updateOne(book, update);

            book = new Document("isbn", isbn);

            // get updated book based on the ISBN to be shown in the bookshelf page
            ArrayList<Document> updatedBook = collection.find(book).into(new ArrayList<>());

            countData = 1;

            dataBooks.put("books", updatedBook);
            statusMap.put("status", "OK");

            transactionStatus = "success";

            endReqMongo = System.currentTimeMillis();

        }catch (Exception e){

            // provide user with message if there is an error in connecting to MongoDB
            dataBooks.put("books", new ArrayList<>());
            statusMap.put("status", "Third-party API unavailable");
            transactionStatus = "failure";
            endReqMongo = System.currentTimeMillis();
        }

        responseMap.putAll(statusMap);
        responseMap.putAll(dataBooks);

        String jsonBooks = gson.toJson(responseMap);

        long timeWSSendRepToUser = System.currentTimeMillis();

        insertLog(userAgent, userIP, userPort, routing, timeWSGetUserRequest, startRegMongo, endReqMongo, timeWSSendRepToUser, transactionStatus, "-", jsonBooks, requestMethod, requestURI, protocol, scheme, countData, requestQuery);

        return jsonBooks;
    }

    /**
     * This function retrieves all logs from MongoDB.
     * log will be shown in the logs page in the dashboard utilizing javascript datatable library.
     * @return JSON data of all logs
     */
    public JsonArray getLogs() {

        JsonArray dataLogs = new JsonArray();

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            MongoCollection<Document> collection = database.getCollection(LOG_ACT);

            dataLogs = collection.find()
                    .sort(Sorts.ascending("timeWSGetUserRequest"))
                    .into(new ArrayList<>()).stream()
                    .map(Document::toJson)
                    .map(JsonParser::parseString)
                    .collect(JsonArray::new, JsonArray::add, JsonArray::addAll);

        }

        return dataLogs;
    }

    /**
     * This function retrieves top 5 keyword rank from MongoDB.
     * The keyword rank will be shown in the dashboard analytics page.
     * @return JSON data of top 5 keyword rank
     */
    public JsonArray getKeywordRank() {

        JsonArray dataKeywordRank = new JsonArray();

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            MongoCollection<Document> collection = database.getCollection(LOG_ACT);

            AggregateIterable<Document> result = collection.aggregate(Arrays.asList(
                    Aggregates.match(Filters.ne("keyword", "-")),
                    Aggregates.group("$keyword", Accumulators.sum("count", 1)),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(5) // get top 5 keyword rank
            ));

            for (Document doc : result) {
                dataKeywordRank.add(JsonParser.parseString(doc.toJson()));
            }
        }

        return dataKeywordRank;
    }

    /**
     * This function retrieves top 5 book category rank on user bookshelf page.
     * The book category rank will be shown in the dashboard analytics page.
     * @return JSON data of top 5 category rank
     */
    public JsonArray getCategoryRank() {

        JsonArray dataCategoryRank = new JsonArray();

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            MongoCollection<Document> collection = database.getCollection(FOUND_BOOKS);

            AggregateIterable<Document> result = collection.aggregate(Arrays.asList(
                    Aggregates.match(Filters.eq("statusFavorite", 1)),
                    Aggregates.group("$category", Accumulators.sum("count", 1)),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(5)
            ));

            // Convert result to JSONArray
            for (Document doc : result) {
                dataCategoryRank.add(JsonParser.parseString(doc.toJson()));
            }
        }

        return dataCategoryRank;
    }

    /**
     * This function retrieves transaction trend between android-webservice-Google BooksAPI
     * The trend will show the network latency per second.
     * The transaction trend will be shown in the dashboard analytics page in line chart.
     * @return JSON data of transaction trend
     */
    public JsonArray getTransactionTrend() {

        long startOfDay = LocalDate.now().atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli();
        long endOfDay = LocalDate.now().plusDays(1).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli();

        // Create the filter to find documents for today's date
        Bson todayFilter = Filters.and(
                Filters.gte("timeWSGetUserRequest", startOfDay),  // Greater than or equal to start of day
                Filters.lt("timeWSGetUserRequest", endOfDay)     // Less than end of day
        );

        JsonArray dataTransactionTrend = new JsonArray();

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            MongoCollection<Document> collection = database.getCollection(LOG_ACT);

            Bson projection = Projections.fields(
                    Projections.include("timeWSGetUserRequest", "WSProcessingTime")
            );

            Document result = collection.find(todayFilter)
                    .projection(projection)
                    .first();

            for (Document doc : collection.find().projection(result)) {
                dataTransactionTrend.add(JsonParser.parseString(doc.toJson()));
            }
        }

        return dataTransactionTrend;
    }

    /**
     * This function retrieves data summary of
     * The data summary includes the statistics of successful and failed transactions, the type of client software used,
     * and the webservice routing.
     * @param table Collection name
     * @param field Field name
     * @return JSON data of data summary
     */
    public JsonArray getDataSummary(String table, String field) {

        JsonArray dataSummary = new JsonArray();

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            MongoCollection<Document> collection = database.getCollection(table);

            AggregateIterable<Document> result = collection.aggregate(Arrays.asList(
                    Aggregates.group("$"+field, Accumulators.sum("count", 1))
            ));

            for (Document doc : result) {
                dataSummary.add(JsonParser.parseString(doc.toJson()));
            }
        }

        return dataSummary;
    }

    /**
     * This function retrieves book history from MongoDB.
     * The book history will be shown in the bookshelf page in the android application.
     * @param timeWSGetUserRequest Time when web service get user request
     * @param userAgent User-Agent of the client
     * @param userIP IP address of the client
     * @param userPort Port of the client
     * @param routing Routing of the client
     * @param requestMethod Request method of the transaction. e.g. GET, POST
     * @param requestURI Request URI of the transaction. e.g. /books, /bookshelf, /logs
     * @param protocol Protocol of the transaction
     * @param scheme Scheme of the transaction
     * @param page Page of the transaction. e.g. bookshelf, books
     * @return JSON data of book history
     */
    public String getHistory(long timeWSGetUserRequest, String userAgent, String userIP, int userPort, String routing, String requestMethod, String requestURI, String protocol, String scheme, String page) {

        Gson gson = new Gson();

        String transactionStatus = "-";
        String requestQuery = "-";

        Map<String, ArrayList<Document>> dataBooks = new HashMap<>();
        Map<String, String> statusMap = new HashMap<>();
        Map<String, Object> responseMap = new HashMap<>();
        ArrayList<Document> uniqueBooks = new ArrayList<>();

        long startRegMongo = System.currentTimeMillis();
        long endReqMongo = 0;

        int countData = 0;

        try (MongoClient mongoClient = MongoClients.create(URI)) {

            MongoDatabase database = mongoClient.getDatabase(DB_NAME);

            MongoCollection<Document> collection = database.getCollection(FOUND_BOOKS);

            /** get unique books from the book history and statusFavorite is 1
             * we also record userIP to record user's favorite book
             */
            if(page.equals("bookshelf")){

                uniqueBooks = collection.aggregate(
                        Arrays.asList(
                                match(eq("statusFavorite", 1)), // Add conditions for statusFavorite
                                group("$isbn", first("doc", "$$ROOT")),
                                replaceRoot("$doc"),
                                project(fields(exclude("_id"),
                                        include("isbn", "title", "authors", "publisher", "year", "category", "desc", "pageCount", "rating", "thumbnail", "id", "statusFavorite")
                                ))
                        )
                ).into(new ArrayList<>());

                requestQuery = "collection.aggregate(\n" +
                        "                        Arrays.asList(\n" +
                        "                                match(and(eq('statusFavorite', 1), eq('userIP', userIP))), // Add conditions for statusFavorite and userIP\n" +
                        "                                group('$isbn', first('doc', '$$ROOT')),\n" +
                        "                                replaceRoot('$doc'),\n" +
                        "                                project(fields(exclude('_id'),\n" +
                        "                                        include('isbn', 'title', 'authors', 'publisher', 'year', 'category', 'desc', 'pageCount', 'rating', 'thumbnail', 'id', 'statusFavorite')\n" +
                        "                                ))\n" +
                        "                        )\n" +
                        "                ).into(new ArrayList<>());";

            }else {
                uniqueBooks = collection.aggregate(
                        Arrays.asList(
                                group("$isbn", first("doc", "$$ROOT")),
                                replaceRoot("$doc"),
                                project(fields(exclude("_id"),
                                        include("isbn", "title", "authors", "publisher", "year", "category", "desc", "pageCount", "rating", "thumbnail", "id", "statusFavorite")
                                )),
                                limit(9)
                        )
                ).into(new ArrayList<>());

                requestQuery = "collection.aggregate(\n" +
                        "                        Arrays.asList(\n" +
                        "                                group('$isbn', first('doc', '$$ROOT')),\n" +
                        "                                replaceRoot('$doc'),\n" +
                        "                                project(fields(exclude('_id'),\n" +
                        "                                        include('isbn', 'title', 'authors', 'publisher', 'year', 'category', 'desc', 'pageCount', 'rating', 'thumbnail', 'id', 'statusFavorite')\n" +
                        "                                )),\n" +
                        "                                limit(9)\n" +
                        "                        )\n" +
                        "                ).into(new ArrayList<>());";

            }

            countData = uniqueBooks.size();

            String dataStatus = countData == 0 ? "No Data Found" : "OK";

            endReqMongo = System.currentTimeMillis();

            dataBooks.put("books", uniqueBooks);
            statusMap.put("status", dataStatus);

            transactionStatus = "success";

        }catch (Exception e){

            dataBooks.put("books", new ArrayList<>());
            statusMap.put("status", "Third-party API unavailable");
            transactionStatus = "failure";
            endReqMongo = System.currentTimeMillis();
        }

        responseMap.putAll(statusMap);
        responseMap.putAll(dataBooks);

        String jsonBooks = gson.toJson(responseMap);

        long timeWSSendRepToUser = System.currentTimeMillis();

        // this log will be executed once user open android application and bookshelf page
        insertLog(userAgent, userIP, userPort, routing, timeWSGetUserRequest, startRegMongo, endReqMongo, timeWSSendRepToUser, transactionStatus, "-", jsonBooks, requestMethod, requestURI, protocol, scheme, countData, requestQuery);

        return jsonBooks;
    }

}

public class ReadaholicModel {
    final String GBOOKS_KEY = "AIzaSyDYO7jcdEgDmtqXZ00NM1VbwIKGHbwowck";
    final String GBOOKS_API = "https://www.googleapis.com/books/v1/volumes?q=";

    Utility utility = new Utility();
    MongoDBConnector mongoDBConnector = new MongoDBConnector();

    private boolean keywordValidation(String keyWord) {
        return keyWord != null && !keyWord.isEmpty() && keyWord.length() >= 3 && keyWord.length() <= 20 && Pattern.compile("^[a-zA-Z0-9 ]+$").matcher(keyWord).matches();
    }

    public String searchBook(String keyWord, long timeWSGetUserRequest, String userAgent, String userIP, int userPort, String routing, String requestMethod, String URI, String protocol, String scheme) throws UnsupportedEncodingException {

        Gson gsonBooks = new Gson();

        // these set of maps will be used to format Json response
        ArrayList<Book> books = new ArrayList<>();
        Map<String, ArrayList<Book>> dataBooks = new HashMap<>();
        Map<String, String> statusMap = new HashMap<>();
        Map<String, Object> responseMap = new HashMap<>();

        String keyWordInfo = "";
        boolean isError = true;

        // this is a set of server-side validation to check if the keyword is valid
        if (keyWord == null || keyWord.isEmpty()) {
            keyWordInfo = "Keyword is empty";
            isError = false;
        }

        // keyword length should be between 3 and 20 characters
        if (keyWord.length() < 3 || keyWord.length() > 20) {
            keyWordInfo = "Invalid keyWord length";
            isError = false;
        }

        // keyword should be alphanumeric
        if (!Pattern.compile("^[a-zA-Z0-9 ]+$").matcher(keyWord).matches()) {
            keyWordInfo = "Keyword should be not empty and alphanumeric";
            isError = false;
        }

        long startReqGBooks = 0;
        long endReqGBooks = 0;
        int countData = 0;
        String transactionStatus = "-";
        String message = "-";
        String requestQuery = "-";

        // if there is no error in the server-side input, we will proceed to fetch JSON data from Google Books API
        if(isError){

            int maxResults = 10;

            // to handle space in the keyword
            String searchTag = URLEncoder.encode(keyWord, "UTF-8");

            String gBooksURL = GBOOKS_API+searchTag+"&maxResults="+maxResults;
            requestQuery = gBooksURL;

            startReqGBooks = System.currentTimeMillis();

            String response = "";

            int statusCode=0;

            // check if the trust manager and https connection will be valid
            utility.checkTrustManager();

            try {

                URL url = new URL(gBooksURL);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
                String str;

                while ((str = in.readLine()) != null) {
                    response += str;
                }

                in.close();

                statusCode = connection.getResponseCode();

            } catch (Exception e) {
                // the connection problem can indicate that the third-party API is unavailable
                message = "Third-party API unavailable";
                books = new ArrayList<>();
                transactionStatus = "failure";
                endReqGBooks = System.currentTimeMillis();
            }

            // if the response code is 200, we will proceed to parse the JSON data
            if(statusCode == 200){

                JsonParser parser = new JsonParser();
                JsonElement bookTree = parser.parse(response);

                JsonArray jsonArr = bookTree.getAsJsonObject().getAsJsonArray("items");

                countData = jsonArr.size();
                int countValidData = 0;

                // this for loop will exclude unnecessary information we got from Google Books API
                for (int i = 0; i < countData; i++) {

                    // to handle JsonElement carefully, we create several usefully method in Utility class
                    String title = utility.toTitleCase(utility.getJsElement(jsonArr, "title", i));
                    String publisher = utility.toTitleCase(utility.getJsElement(jsonArr, "publisher", i));
                    String year = utility.getJsElement(jsonArr, "publishedDate", i).split("-")[0];
                    String desc = utility.getJsElement(jsonArr, "description", i);
                    String rating = utility.getJsElement(jsonArr, "averageRating", i)+"/5";
                    String id = utility.getJsElement(jsonArr, "id", i);

                    String isbn = "-";
                    if(!utility.checkJsEl(jsonArr, "industryIdentifiers", i)){
                        isbn = jsonArr.get(i).getAsJsonObject().get("volumeInfo").getAsJsonObject().get("industryIdentifiers").getAsJsonArray().get(0).getAsJsonObject().get("identifier").getAsString();
                    }

                    String authors = "-";
                    if(!utility.checkJsEl(jsonArr, "authors", i)){
                        JsonArray dataAuthors = jsonArr.get(i).getAsJsonObject().get("volumeInfo").getAsJsonObject().get("authors").getAsJsonArray();

                        // there will be multiple authors in a book, so we need to handle it carefully
                        for (int j = 0; j < dataAuthors.size(); j++) {
                            authors += utility.toTitleCase(dataAuthors.get(j).getAsString());
                            if (j != dataAuthors.size() - 1) {
                                authors += ", ";
                            }
                        }
                    }

                    int pageCount = 0;
                    if(!utility.checkJsEl(jsonArr, "pageCount", i)){
                        pageCount = jsonArr.get(i).getAsJsonObject().get("volumeInfo").getAsJsonObject().get("pageCount").getAsInt();
                    }

                    String category = "-";
                    if(!utility.checkJsEl(jsonArr, "categories", i)){
                        category = jsonArr.get(i).getAsJsonObject().get("volumeInfo").getAsJsonObject().get("categories").getAsJsonArray().get(0).getAsString();
                    }

                    String thumbnail = "-";
                    if(!utility.checkJsEl(jsonArr, "imageLinks", i)){
                        try {
                            // to handle image URL, we convert it to base64 before sending it to android application
                            thumbnail = utility.imageURLToBase64(jsonArr.get(i).getAsJsonObject().get("volumeInfo").getAsJsonObject().get("imageLinks").getAsJsonObject().get("thumbnail").getAsString());
                        } catch (Exception e) {
                            message = "Third-party API invalid data";
                            throw new RuntimeException(e);
                        }
                    }

                    Book book = new Book(isbn, title, authors, publisher, year, category, desc, pageCount, rating, thumbnail, id, 0);

                    books.add(book);

                    // we will record the book history in MongoDB to provide bookshelf feature in android application
                    mongoDBConnector.insertBook(isbn, title, authors, publisher, year, category, desc, rating, thumbnail, id, pageCount, 0, userIP);

                    countValidData++;
                }

                // we will compare the count of valid data with the count of data we got from Google Books API
                if(countValidData != countData){
                    message = "Third-party API invalid data";
                    transactionStatus = "failure";
                }else{
                    message = "OK";
                    transactionStatus = "success";
                }

                endReqGBooks = System.currentTimeMillis();
            }

        } else {
            books = new ArrayList<>();
            message = "Invalid Server-Side input. "+keyWordInfo;
            transactionStatus = "failure";
        }

        // prepare JSON response
        dataBooks.put("books", books);
        statusMap.put("status", message);
        responseMap.putAll(statusMap);
        responseMap.putAll(dataBooks);

        String jsonBooks = gsonBooks.toJson(responseMap);

        long timeWSSendRepToUser = System.currentTimeMillis();

        // we will record this searching book transaction to MongoDB
        mongoDBConnector.insertLog(userAgent, userIP, userPort, routing, timeWSGetUserRequest, startReqGBooks, endReqGBooks, timeWSSendRepToUser, transactionStatus, keyWord, jsonBooks, requestMethod, URI, protocol, scheme, countData, requestQuery);

        return jsonBooks;
    }
}